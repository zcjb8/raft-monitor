### express 实现的服务器端接口

运行方式

```bash
npm i
npm run dev # 需要nodemon插件，直接自行全局安装即可
```

## 项目使用MongoDB
