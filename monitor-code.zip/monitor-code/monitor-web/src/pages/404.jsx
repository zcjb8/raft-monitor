import React, { Component } from 'react';

class Pagenotfound extends Component {
    render() {
        return (
            <div>
                <h1>404</h1>
            </div>
        );
    }
}

export default Pagenotfound;
