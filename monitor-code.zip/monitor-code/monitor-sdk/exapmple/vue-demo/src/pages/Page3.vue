<script setup  name="page3">

</script>
<template>
  <div>
    <h2>page3</h2>
  </div>
</template>
