import React from 'react';

const Index = () => {
  return (
    <div>
      <h2>页面停留统计</h2>
    </div>
  );
}

export default Index;