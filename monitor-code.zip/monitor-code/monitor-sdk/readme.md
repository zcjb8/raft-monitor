运行方式

```bash
npm link
# 在项目里面 `npm link monitor-sdk` 即可安装到项目中
```

## 项目使用MongoDB